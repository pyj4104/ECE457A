function y = multipeak(x);
% Evaluation function
y = x + sin(x)+cos(x);